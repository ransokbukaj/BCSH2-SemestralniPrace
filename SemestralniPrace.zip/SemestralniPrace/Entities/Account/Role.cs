using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Account
{
    public enum Role
    {
        Admin = 1,
        Standard = 2
    }
}
