﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseAccess.Interface;
using Entities;

namespace DatabaseAccess
{
    public class BuyerRepository : IBuyerRepository
    {
        public List<Buyer> GetList()
        {
            throw new NotImplementedException();
        }

        public void SaveItem(Buyer buyer)
        {
            throw new NotImplementedException();
        }

        public void DeleteItem(int id)
        {
            throw new NotImplementedException();
        }
    }
}
