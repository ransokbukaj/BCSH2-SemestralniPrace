﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DatabaseAccess.Interface;
using Entities;

namespace DatabaseAccess
{
    public class SaleRepository : ISaleRepository
    {
        public List<Sale> GetList()
        {
            throw new NotImplementedException();
        }

        public void SaveItem(Sale sale)
        {
            throw new NotImplementedException();
        }

        public void DeleteItem(int id)
        {
            throw new NotImplementedException();
        }
    }
}
